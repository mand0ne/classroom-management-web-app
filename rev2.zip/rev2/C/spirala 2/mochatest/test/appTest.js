let assert = chai.assert;

let periodicna = [
    {dan: 5,
    semestar: "ljetni",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"}
];

let periodicna1 = [
    {dan: 1,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"}
];

let vanredna1 = [
    {datum: "10.11.2019.",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {datum: "29.11.2019.",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {datum: "15.11.2019.",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"}
];
    
let vanredna = [
    {datum: "05.11.2019.",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {datum: "05.11.2019.",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"}
];

let cijeli = [
    {dan: 5,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {dan: 0,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {dan: 4,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {dan: 1,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {dan: 2,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {dan: 3,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"},
    {dan: 6,
    semestar: "zimski",
    pocetak: "18:45",
    kraj: "20:00",
    naziv: "0-01",
    predavac: "Sabiha"}
];

describe('Kalendar', function() {
 describe('obojiZauzeca()', function() {
   it('Ako nema učitanih podataka, sale su slobodne', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let godina = datum.getFullYear();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke([], []);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "19:00", "20:00");
    let neobojene = document.getElementsByClassName("slobodna").length;
       assert.equal(neobojene, 32 - new Date(godina, mjesec, 32).getDate());
   });

   it('Duple vrijednosti zauzeća boje dan', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke([], vanredna);
        Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
        assert.equal(document.getElementsByClassName("zauzeta").length, 1);
   });

   it('Zauzeće ljetnog semestra nije vidljivo u zimskom', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let godina = datum.getFullYear();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke([{
        dan: 1,
        semestar: "ljetni",
        pocetak: "12:15",
        kraj: "13:00",
        naziv: "1-02",
        predavac: "Kolumbo"
    }], []);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let neobojene = document.getElementsByClassName("slobodna").length;
    assert.equal(neobojene, 32 - new Date(godina, mjesec, 32).getDate());
   });

   it('Vanredno zauzeće nekog drugog mjeseca nije vidljivo', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let godina = datum.getFullYear();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke([], [{
        datum: "08.12.2019.",
        pocetak: "18:45",
        kraj: "20:00",
        naziv: "0-01",
        predavac: "Sabiha"
    }]);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let neobojene = document.getElementsByClassName("slobodna").length;
    assert.equal(neobojene, 32 - new Date(godina, mjesec, 32).getDate());
   });

   it('Svi termini zauzeti', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke(cijeli, []);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let neobojene = document.getElementsByClassName("slobodna").length;
    assert.equal(neobojene, 0);
   });

   it('Dvostruko pozivanje funkcije rezultira istim zauzećem', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke(cijeli, []);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let neobojene1 = document.getElementsByClassName("slobodna").length;
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let neobojene2 = document.getElementsByClassName("slobodna").length;
    assert.equal(neobojene1+neobojene2, 0);
   });

   it('Pamte se samo posljednji učitani podaci', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke(cijeli, []);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let neobojene1 = document.getElementsByClassName("slobodna").length;
    Kalendar.ucitajPodatke([], vanredna);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let neobojene2 = document.getElementsByClassName("slobodna").length;
    assert.notEqual(neobojene1, neobojene2);
   });

   it('Preklapanje vanrednih i periodičnih zauzeća rezultira unijom zauzeća', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke(periodicna1, vanredna);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let obojena = document.getElementsByClassName("zauzeta").length;
    assert.equal(obojena, 5);
   });

   it('Pravilno ispisivanje raznovrsnih zauzeća', function() {
    let datum = new Date();
    let mjesec = datum.getMonth();
    let tijelo = document.getElementById("tijelo-kalendara");
    Kalendar.ucitajPodatke(periodicna1, vanredna1);
    Kalendar.obojiZauzeca(tijelo, mjesec, "0-01", "18:00", "20:00");
    let obojena = document.getElementsByClassName("zauzeta").length;
    assert.equal(obojena, 8);
   });
 });

 describe('iscrtajKalendar()', function() {
    it('Mjesec sa 30 dana', function() {
        Kalendar.iscrtajKalendar(document.getElementById("tijelo-kalendara"), 8);
        assert.equal(32 - new Date(2019, 8, 32).getDate(), 30);
    });

    it('Mjesec sa 31nim danom', function() {
        Kalendar.iscrtajKalendar(document.getElementById("tijelo-kalendara"), 4);
        assert.equal(32 - new Date(2019, 0, 32).getDate(), 31);
    });

    it('Prvi dan je petak', function() {
        Kalendar.iscrtajKalendar(document.getElementById("tijelo-kalendara"), 10);
        let datum = new Date(2019, 10, 1);
        assert.equal(datum.getDay(), 5);
    });

    it('Zadnji dan je subota', function() {
        Kalendar.iscrtajKalendar(document.getElementById("tijelo-kalendara"), 10);
        let datum = new Date(2019, 10, 30);
        assert.equal(datum.getDay(), 6);
    });

    it('Januar', function() {
        Kalendar.iscrtajKalendar(document.getElementById("tijelo-kalendara"), 0);
        let datum = new Date(2019, 1, 1);
        assert.equal(datum.getDay(), 5);
    });

    it('Februar 28 dana', function() {
        Kalendar.iscrtajKalendar(document.getElementById("tijelo-kalendara"), 1);
        assert.equal(32 - new Date(2019, 1, 32).getDate(), 28);
    });

    it('April - prvi dan ponedjeljak', function() {
        Kalendar.iscrtajKalendar(document.getElementById("tijelo-kalendara"), 3);
        let datum = new Date(2020, 3, 1);
        assert.equal(datum.getDate(), 1);
    });
 });
});
