let Kalendar = (function(){
    
    let trenutniDatum = new Date();
    let trenutniMjesec = trenutniDatum.getMonth();
    let godina = trenutniDatum.getFullYear();
    let nazivMjeseca = document.getElementById("nazivMjeseca");
    let mjeseci = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
    iscrtajKalendarImpl(document.getElementById("tijelo-kalendara"), trenutniMjesec);       
    let periodicna = [
        {  
            dan: 1,
            semestar: "ljetni",
            pocetak: "12:15",
            kraj: "13:00",
            naziv: "1-02",
            predavac: "Kolumbo"
        },
        {  
           dan: 5,
           semestar: "zimski",
           pocetak: "18:45",
           kraj: "20:00",
           naziv: "0-01",
           predavac: "Sabiha"
        }
    ];
        
    let vanredna = [
        {  
            datum: "04.11.2019.",
            pocetak: "12:15",
            kraj: "13:00",
            naziv: "1-05",
            predavac: "Koko"
        },
        {  
            datum: "05.01.2019.",
            pocetak: "18:45",
            kraj: "20:00",
            naziv: "0-01",
            predavac: "Migel"
        },
        {  
            datum: "28.11.2019.",
            pocetak: "18:45",
            kraj: "20:00",
            naziv: "0-01",
            predavac: "Alehandro"
        }];
    let zauzecaPeriodicna = new Array();
    let zauzecaVanredna = new Array();
    ucitajPodatkeImpl(periodicna, vanredna);
    
    document.getElementById("izmjena").addEventListener("change", function(){
        document.getElementById("tijelo-kalendara").innerHTML = "";
        iscrtajKalendarImpl(document.getElementById("tijelo-kalendara"), trenutniMjesec);
        /*ucitajPodatkeImpl(periodicna, vanredna);*/
        obojiZauzecaImpl(
            document.getElementById("tijelo-kalendara"),
            trenutniMjesec,
            document.getElementById("prostorije").value,
            document.getElementById("pocetak").value,
            document.getElementById("kraj").value
        );
    });

    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
        iscrtajKalendarImpl(kalendarRef, mjesec);
        let duzina = zauzecaPeriodicna.length;
        let prviDan = ((new Date(godina, mjesec)).getDay()+6)%7;
        let k;
        let brojDana = 32 - new Date(godina, mjesec, 32).getDate();
        if(duzina){
            for(let i=0; i<duzina; i++)
            if((((mjesec >= 9 && mjesec <=11) || mjesec === 0) && zauzecaPeriodicna[i].semestar === "zimski")
               || (mjesec >= 1 && mjesec <=5 && zauzecaPeriodicna[i].semestar === "ljetni"))
                if(sala === zauzecaPeriodicna[i].naziv && zauzecaPeriodicna[i].pocetak >= pocetak && zauzecaPeriodicna[i].kraj <= kraj)
                    for(let j=0; j<kalendarRef.rows.length-1; j++)
                        if(brojDana+prviDan > (i+1)*(j+1) && kalendarRef.rows[j].cells[zauzecaPeriodicna[i].dan] != "")
                            kalendarRef.rows[j].cells[zauzecaPeriodicna[i].dan].className = "datum zauzeta";
        }   

        if(zauzecaVanredna.length){
            for(let i=0; i<zauzecaVanredna.length; i++){
                let brojac = 0;
                if((zauzecaVanredna[i].datum).substr(3,2) === (mjesec+1).toString() && (zauzecaVanredna[i].datum).substr(6,4) === godina.toString()
                && zauzecaVanredna[i].naziv === sala && zauzecaVanredna[i].pocetak >= pocetak && zauzecaVanredna[i].kraj <= kraj)
                for(let j=0; j<kalendarRef.rows.length-1; j++){
                     if(j === 0)
                         k = prviDan-1;
                    else k = 0;
                    for(; k<7; k++){
                        if(brojac === parseInt((zauzecaVanredna[i].datum).substr(0, 2))){
                            kalendarRef.rows[j].cells[k].className = "datum zauzeta";
                            j = kalendarRef.rows.length;
                        }
                        brojac++;
                    }       
                }
            }
        }
    }

    function ucitajPodatkeImpl(periodicna, vanredna){
        zauzecaPeriodicna = [];
        zauzecaVanredna = [];
        let duzina = periodicna.length;
        for(let i=0; i<duzina; i++){
            zauzecaPeriodicna.push(new Object());
            zauzecaPeriodicna[i] = periodicna[i];
        }
        duzina = vanredna.length;
        for(let i=0; i<duzina; i++){
            zauzecaVanredna.push(new Object());
            zauzecaVanredna[i] = vanredna[i];
        }
    }

    function iscrtajKalendarImpl(kalendarRef, mjesec){
        let prviDan = ((new Date(godina, mjesec)).getDay()+6)%7;
        let brojDana = 32 - new Date(godina, mjesec, 32).getDate();
        kalendarRef.innerHTML = "";
        nazivMjeseca.innerHTML = mjeseci[mjesec] + " " + godina;
        let dan = 1;
        for (let i = 0; i < 6; i++) {
            let row = document.createElement("tr");
            for (let j = 0; j < 7; j++) {
                if (i === 0 && j < prviDan) {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode("");
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                }
                else if (dan > brojDana) {
                    break;
                }
                else {
                    let cell = document.createElement("td");
                    cell.className = "datum slobodna";
                    let cellText = document.createTextNode(dan);
                    if (dan === trenutniDatum.getDate() && godina === trenutniDatum.getFullYear() && mjesec === trenutniDatum.getMonth()) {
                        cell.classList.add("bg-info");
                    } 
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                    dan++;
                }
            }
            kalendarRef.appendChild(row); 
        }
    }

    document.getElementById("sljedeciMjesec").onclick = function() {sljedeciMjesecImpl()};
    document.getElementById("prethodniMjesec").onclick = function() {prethodniMjesecImpl()};

    function sljedeciMjesecImpl(){
        godina = (trenutniMjesec === 11) ? godina : godina;
        if(trenutniMjesec < 11)
            trenutniMjesec++;
        obojiZauzecaImpl(document.getElementById("tijelo-kalendara"), trenutniMjesec, document.getElementById("prostorije").value, 
        document.getElementById("pocetak").value, document.getElementById("kraj").value);
    }
    
    function prethodniMjesecImpl() {
        godina = (trenutniMjesec === 0) ? godina : godina;
        if(trenutniMjesec > 0)
            trenutniMjesec--;
        obojiZauzecaImpl(document.getElementById("tijelo-kalendara"), trenutniMjesec, document.getElementById("prostorije").value, 
        document.getElementById("pocetak").value, document.getElementById("kraj").value);
    }

   

    return {
        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl, 
        iscrtajKalendar: iscrtajKalendarImpl
    }
}());


    