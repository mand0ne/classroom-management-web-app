let Kalendar = (function() {
    function obojiZauzecaImp1(kalendarRef, mjesec, sala, pocetak, kraj) {
        
    }
    function ucitajPodatkeImp1(periodicna, vanredna) {
        
    }
    return {
        obojiZauzeca: obojiZauzecaImp1,
        ucitajPodatke: ucitajPodatkeImp1
    }
}());