let assert = chai.assert;

describe("Kalendar", function() {
  describe("obojiZauzeca()", function() {
    it("treba obojiti sve zeleno kada se nista ne proslijedi za ucitavanje podataka", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 10);

      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++)
        assert.equal(dani[i].classList.contains("zauzeta"), false);
    });

    it("treba obojiti svaku srijedu iako postoje preklapanja", function() {
      Kalendar.ucitajPodatke(
        [
          {
            dan: 2,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ],
        [
          {
            datum: "6.11.2019",
            pocetak: "12:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            datum: "13.11.2019",
            pocetak: "12:00",
            kraj: "15:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ]
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );

      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        if (i % 7 === 2) {
          assert.equal(dani[i].classList.contains("slobodna"), false);
        } else {
          assert.equal(dani[i].classList.contains("zauzeta"), false);
        }
      }
    });

    it("postoji periodicno zauzece za drugi semestar", function() {
      Kalendar.ucitajPodatke(
        [
          {
            dan: 2,
            semestar: "ljetni",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ],
        []
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );

      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        assert.equal(dani[i].classList.contains("zauzeta"), false);
      }
    });

    it("postoji zauzece za drugi mjesec", function() {
      Kalendar.ucitajPodatke(
        [],
        [
          {
            datum: "6.10.2019",
            pocetak: "12:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            datum: "13.12.2019",
            pocetak: "12:00",
            kraj: "15:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ]
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );

      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        assert.equal(dani[i].classList.contains("zauzeta"), false);
      }
    });

    it("sve zauzeto", function() {
      Kalendar.ucitajPodatke(
        [
          {
            dan: 0,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            dan: 1,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            dan: 2,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            dan: 3,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            dan: 4,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            dan: 5,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            dan: 6,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ],
        []
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );

      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        assert.equal(dani[i].classList.contains("slobodna"), false);
      }
    });

    it("oboji zauzece pozvano dva puta", function() {
      Kalendar.ucitajPodatke(
        [
          {
            dan: 2,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            dan: 3,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ],
        []
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );
      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        if (i % 7 === 2 || i % 7 === 3) {
          assert.equal(dani[i].classList.contains("slobodna"), false);
        } else {
          assert.equal(dani[i].classList.contains("zauzeta"), false);
        }
      }

      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );
      for (var i = 0; i < dani.length; i++) {
        if (i % 7 === 2 || i % 7 === 3) {
          assert.equal(dani[i].classList.contains("slobodna"), false);
        } else {
          assert.equal(dani[i].classList.contains("zauzeta"), false);
        }
      }
    });

    it("oboji zauzece mijenjanje podataka", function() {
      Kalendar.ucitajPodatke(
        [
          {
            dan: 2,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ],
        []
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );
      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        if (i % 7 === 2) {
          assert.equal(dani[i].classList.contains("slobodna"), false);
        } else {
          assert.equal(dani[i].classList.contains("zauzeta"), false);
        }
      }

      Kalendar.ucitajPodatke(
        [
          {
            dan: 5,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "13:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ],
        []
      );

      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );
      for (var i = 0; i < dani.length; i++) {
        if (i % 7 === 5) {
          assert.equal(dani[i].classList.contains("slobodna"), false);
        } else {
          assert.equal(dani[i].classList.contains("zauzeta"), false);
        }
      }
    });

    it("postoji zauzece za drugo vrijeme na isti dan", function() {
      Kalendar.ucitajPodatke(
        [],
        [
          {
            datum: "6.11.2018",
            pocetak: "13:00",
            kraj: "17:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            datum: "13.11.2020",
            pocetak: "13:00",
            kraj: "15:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ]
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );

      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        assert.equal(dani[i].classList.contains("zauzeta"), false);
      }
    });

    it("postoji zauzece za isti mjesec druga godina", function() {
      Kalendar.ucitajPodatke(
        [],
        [
          {
            datum: "6.11.2019",
            pocetak: "10:00",
            kraj: "12:00",
            naziv: "0-01",
            predavac: "Dzan"
          },
          {
            datum: "13.11.2019",
            pocetak: "13:00",
            kraj: "15:00",
            naziv: "0-01",
            predavac: "Dzan"
          }
        ]
      );
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-01",
        "12:00",
        "13:00"
      );

      let dani = document.getElementsByClassName("dan");
      for (var i = 0; i < dani.length; i++) {
        assert.equal(dani[i].classList.contains("zauzeta"), false);
      }
    });
  });

  describe("iscrtajKalendar()", function() {
    it("treba se ucitati trideset dana", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 8);
      let dani = document.getElementsByClassName("slobodna");
      assert.equal(30, dani.length);
    });

    it("treba se ucitati trideset jedan dan", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 4);
      let dani = document.getElementsByClassName("slobodna");
      assert.equal(31, dani.length);
    });

    it("trenutni mjesec (Novembar) prvi dan petak", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), new Date().getMonth());
      let dani = document.getElementsByClassName("dan");
      assert.equal(1, dani[4].innerHTML);
    });

    it("trenutni mjesec (Novembar) zadnji dan subota", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), new Date().getMonth());
      let dani = document.getElementsByClassName("dan");
      assert.equal(30, dani[dani.length - 2].innerHTML);
    });

    it("crtanje januara, 31 dan i prvi dan utorak", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
      let dani = document.getElementsByClassName("slobodna");
      assert.equal(31, dani.length);

      dani = document.getElementsByClassName("dan");
      assert.equal(1, dani[1].innerHTML);
    });

    it("crtanje februara, 28 dana", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
      let dani = document.getElementsByClassName("slobodna");
      assert.equal(28, dani.length);
    });

    it("crtanje decembra, pocetak nedjelja, kraj utorak", function() {
      Kalendar.ucitajPodatke([], []);
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 11);
      let dani = document.getElementsByClassName("dan");
      assert.equal(1, dani[6].innerHTML);
      assert.equal(31, dani[dani.length - 6].innerHTML);
    });

  });

  
});
