let Kalendar = ( function () {

	var aktivniMjesec = 10;
	var periodicnaZauzeca;
	var vanrednaZauzeca; 
		
	function nazivMjeseca(redniBroj) {
		
		if (redniBroj == 0) {
			return "januar";
		} else if (redniBroj == 1) {
			return "februar";
		} else if (redniBroj == 2) {
			return "mart";
		} else if (redniBroj == 3) {
			return "april";
		} else if (redniBroj == 4) {
			return "maj";
		} else if (redniBroj == 5) {
			return "juni";
		} else if (redniBroj == 6) {
			return "juli";
		} else if (redniBroj == 7) {
			return "august";
		} else if (redniBroj == 8) {
			return "septembar";
		} else if (redniBroj == 9) {
			return "oktobar";
		} else if (redniBroj == 10) {
			return "novembar";
		} else if (redniBroj == 11) {
			return "decembar";
		} else {
			return null;
		}
	
	}
	
	function ucitajPodatkeImp(periodicna, vanredna) {
		periodicnaZauzeca = periodicna;
		vanrednaZauzeca = vanredna;
	}

	function obojiZauzecaImp(kalendarRef, mjesec, sala, pocetak, kraj) {
		
		var kalendar = kalendarRef.children;
		
		var tempMjesec = null;
		var mjesecNaziv = nazivMjeseca(mjesec);
		var daniMjesec = new Array();
	
		for(i=0; i < kalendar.length; i++) {
			if (kalendar[i].id == mjesecNaziv) {
				tempMjesec = kalendar[i];
			}
		} 
		

		 
		 var sedmice = tempMjesec.children;
		 
		 var brojPraznihPozicijaPrvaSedmica = 0;
		 var brojPraznihPozicijaZadnjaSedmica = 0;
		 
		 
		 for (i=2; i < sedmice.length; i++) {
		
			var daniTemp = sedmice[i].children;
			

			for(j=0; j<daniTemp.length; j++) {
				if( (daniTemp[j].className == "dan prazanDan") && (i == 2) ) {
					brojPraznihPozicijaPrvaSedmica++;				
				}
				if( (daniTemp[j].className == "dan prazanDan") && (i != 2) ) {
					brojPraznihPozicijaZadnjaSedmica++;				
				}
			
				if( daniTemp[j].className == "dan" ) {
					elementiDana = daniTemp[j].children;						
					elementStatus = elementiDana[1];
					elementStatus.setAttribute("class", "statusDan slobodna");
				}
				
				daniMjesec.push(daniTemp[j]);
			} 
		 }
		 		 
		 
		  
		  for(i=0; i<vanrednaZauzeca.length; i++) {
			
			datumKomponente = vanrednaZauzeca[i]["datum"].split(".");
			danTemp = datumKomponente[0];
			mjesecTemp = datumKomponente[1];
			godinaTemp = datumKomponente[2];
									
			if ( (mjesecTemp - 1) == mjesec ) {			
				elementiDana = daniMjesec[ brojPraznihPozicijaPrvaSedmica + (danTemp - 1) ].children;			
				elementStatus = elementiDana[1];
				elementStatus.setAttribute("class", "statusDan zauzeta");
			} 
			
		  }
		  

		  
		  for(i=0; i<periodicnaZauzeca.length; i++) {
		  
			
			   var potrebnoObojiti = false;
			   
			   if ( (periodicnaZauzeca[i]["semestar"] == "zimski") && (mjesec == 9 || mjesec == 10 || mjesec == 11 || mjesec == 0) ) {
					potrebnoObojiti = true;
			   }		   
			   if ( (periodicnaZauzeca[i]["semestar"] == "ljetni") && (mjesec == 1 || mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5) ) {
					potrebnoObojiti = true;
			   }
			   			   
			   if(potrebnoObojiti) {				   
				
				   var brojDanaMjesec = daniMjesec.length - brojPraznihPozicijaPrvaSedmica - brojPraznihPozicijaZadnjaSedmica;
				   
				   for( j=periodicnaZauzeca[i]["dan"] ; j<brojDanaMjesec + 7; j=j+7) {   
						if (j < brojPraznihPozicijaPrvaSedmica) continue;
						if (j > brojPraznihPozicijaPrvaSedmica + brojDanaMjesec) continue;					
						elementiDana = daniMjesec[ j ].children;			
						elementStatus = elementiDana[1];
						elementStatus.setAttribute("class", "statusDan zauzeta");							   
				   }
			   }
		  }	
	}
	
	function inicijalizirajKalendarImp() {
		podesiPrikazKalendara();
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), aktivniMjesec, "TEST", "TEST", "TEST");
	}
	
	function podesiPrikazKalendara() {
		var mjeseci = document.getElementById("kalendar").children;
		for (i=0; i<12; i ++) {
			if (i == aktivniMjesec) {
				mjeseci[i].setAttribute("class","pokazi");
			} else {
				mjeseci[i].setAttribute("class","sakrij");
			}
		}
	}
	
	function vratiAktivniMjesecImp () {
		return aktivniMjesec;
	}
	
	function aktivniMjesecNaprijedImp() {
		if (aktivniMjesec == 11) {
			document.getElementById("btnNaredni").disabled = true;
			document.getElementById("btnPrethodni").disabled = false;
		} else {
			document.getElementById("btnNaredni").disabled = false;
			document.getElementById("btnPrethodni").disabled = false;
			aktivniMjesec = aktivniMjesec + 1;
		}
		podesiPrikazKalendara();
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), aktivniMjesec, "TEST", "TEST", "TEST");
	}
	
	function aktivniMjesecNazadImp() {
		if (aktivniMjesec == 0) {
			document.getElementById("btnPrethodni").disabled = true;
			document.getElementById("btnNaredni").disabled = false;
		} else {
			document.getElementById("btnPrethodni").disabled = false;
			document.getElementById("btnNaredni").disabled = false;
			aktivniMjesec = aktivniMjesec -1;
		}
		podesiPrikazKalendara();
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), aktivniMjesec, "TEST", "TEST", "TEST");
	}
	
	return {
		vratiAktivniMjesec: vratiAktivniMjesecImp,
		aktivniMjesecNaprijed: aktivniMjesecNaprijedImp,
		aktivniMjesecNazad : aktivniMjesecNazadImp,
		obojiZauzeca : obojiZauzecaImp,
		ucitajPodatke : ucitajPodatkeImp,
		inicijalizirajKalendar : inicijalizirajKalendarImp		
	}
	
} () );

document.getElementById("btnNaredni").addEventListener("click", Kalendar.aktivniMjesecNaprijed);
document.getElementById("btnPrethodni").addEventListener("click", Kalendar.aktivniMjesecNazad);

var periodicnaZauzecaData = [ { "dan":1, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }, 
							  { "dan":3, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							  { "dan":4, "semestar":"ljetni", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }] ;
var vanrednaZauzecaData = [ { "datum":"15.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"17.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"26.5.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"25.3.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac"}]; 
						
Kalendar.ucitajPodatke(periodicnaZauzecaData, vanrednaZauzecaData);
Kalendar.inicijalizirajKalendar();