window.onload= function (){
    Pozivi.rezervisi();
    Pozivi.otvoriRezervacije();
};

