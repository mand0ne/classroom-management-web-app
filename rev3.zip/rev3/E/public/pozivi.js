let Pozivi = (function(){    
    function otvoriRezervacijeImpl(){
    var req= new XMLHttpRequest();
    req.open('GET', 'http://localhost:8080/zauzeca');
    req.onload=function(){
        var data=JSON.parse(req.responseText);
        var v=data.vandredna;
        var r=data.periodicna;
        Kalendar.ucitajPodatke(r,v);
        };
        console.log('ajax');
    req.send();
    }
    function rezervisiImpl(){
        //console.log('thio',this.otvoriRezervacijeImpl()==null);
        var datumi_p=document.getElementsByClassName('calendar__number');
        var datumi=[];
        for( var i=0; i<datumi_p.length; i++){
            if(datumi_p[i].style.display!='none' && datumi_p[i].style.visibility!='hidden'&& !datumi_p[i].classList.contains('prazno_prije') && !datumi_p[i].childNodes[1].classList.contains('zauzeti')) 
                datumi.push(datumi_p[i]);
        }
        for(var i=0; i<datumi.length; i++){
            console.log(datumi[i].childNodes[1].classList.contains('slobodni'));
            datumi[i].onclick=function(){
                var p;
                var v;
                var data;
                if(confirm('Da li želite da rezervišete ovaj termin?')){
                    var sala=document.getElementById('sale_odabir').value;
                    var periodicna=document.getElementsByName('periodicna')[0].checked;
                    var pocetak=document.getElementsByName('pocetak')[0].value;
                    var kraj=document.getElementsByName('kraj')[0].value;
                    var mjesec= document.getElementById('mjesec').childNodes[1].innerHTML;
                    var semestar;
                    if(mjesec=="Oktobar" || mjesec=="Novembar" || mjesec=="Decembar" || mjesec=="Januar")
                        semestar="zimski";
                    else if(mjesec=="Februar" || mjesec=="Mart" || mjesec=="April" || mjesec=="Maj" || mjesec=="Juni")
                        semestar="ljetni"; 
                    var br_mjeseca;
                    if(mjesec=="Janurar") br_mjeseca=1;
                    else if(mjesec=="Februar") br_mjeseca=2;
                    else if(mjesec=="Mart") br_mjeseca=3;
                    else if(mjesec=="April") br_mjeseca=4;
                    else if(mjesec=="Maj") br_mjeseca=5;
                    else if(mjesec=="Juni") br_mjeseca=6;
                    else if(mjesec=="Juli") br_mjeseca=7;
                    else if(mjesec=="August") br_mjeseca=8;
                    else if(mjesec=="Septembar") br_mjeseca=9;
                    else if(mjesec=="Oktobar") br_mjeseca=10;
                    else if(mjesec=="Novembar") br_mjeseca=11;
                    else if(mjesec=="Decembar") br_mjeseca=12;
                    var kliknuti=parseInt(this.innerHTML.substring(0,1));
                    console.log('eh',kliknuti);
                    var req= new XMLHttpRequest();
                    req.open('GET', 'http://localhost:8080/zauzeca.json');
                    req.onload=function(){
                        data=JSON.parse(req.responseText);
                        v=data.vandredna;
                        p=data.periodicna;
                        if(periodicna){
                            var moguci=[];
                            var x=kliknuti;
                            while(x>0){
                                x=x-7;
                            }                        
                            for(var i=0; i<p.length; i++){
                                if(p[i].kraj==kraj && p[i].pocetak==pocetak && p[i].semestar==semestar && x==p[i].dan)
                                    moguci.push(p[i]);
                            }
                            if(moguci.length!=0)
                                alert('Nije moguće rezervisati salu' + sala +'za navedeni datum' + kliknuti +'/' + br_mjeseca +'/2019 i termin od ' + pocetak +'do' + kraj + '!');
                            else{
                                var data = {"dan":kliknuti, "semestar":semestar, "kraj":kraj, "pocetak":pocetak, "naziv":sala, "predavac":"string"};
                                var xhr = new XMLHttpRequest();
                                xhr.withCredentials = true;
                                xhr.addEventListener("readystatechange", function () {
                                    if (this.readyState === 4) {
                                        console.log(this.responseText);
                                    }
                                    else{
                                        console.log('err');
                                    }
                                });
                                xhr.open("POST", "http://localhost:8080/zauzeca.json");
                                xhr.setRequestHeader("cache-control", "no-cache");
                                xhr.setRequestHeader("content-type", "application/json;charset=UTF-8");
                                xhr.send(JSON.stringify(data));
                                Kalendar.obojiZauzeca(document.getElementById('kalendar'), mjesec-1, sala, pocetak, kraj);
                            }
                        }
                        else{
                            var moguci1=[];
                            for(var i=0; i<v.length; i++){
                                var mjesec_vandredne_rezervacije=parseInt(v[i].datum.substring(3,5));
                                var dan_vandredne_rezervacije=parseInt(v[i].datum.substring(0,2));
                                if(v[i].kraj==kraj && v[i].pocetak==pocetak && mjesec_vandredne_rezervacije==br_mjeseca && dan_vandredne_rezervacije==kliknuti)
                                    moguci1.push(v[i]);
                            }
                            if(moguci1.length!=0)
                                alert('Nije moguće rezervisati salu' + sala +'za navedeni datum' + kliknuti +'/' + br_mjeseca +'/2019 i termin od ' + pocetak +'do' + kraj + '!');
                            else{
                                var data = {"datum":kliknuti+":"+br_mjeseca+":2019", "pocetak":pocetak, "kraj":kraj, "naziv":sala, "predavac":"string"};
                                var xhr = new XMLHttpRequest();
                                xhr.withCredentials = true;
                                xhr.addEventListener("readystatechange", function () {
                                    if (this.readyState === 4) {
                                        console.log(this.responseText);
                                    }
                                    else{
                                        console.log('err');
                                    }
                                });
                                xhr.open("POST", "http://localhost:8080/zauzeca.json");
                                xhr.setRequestHeader("cache-control", "no-cache");
                                xhr.setRequestHeader("content-type", "application/json;charset=UTF-8");
                                xhr.send(JSON.stringify(data));
                                //this.otvoriRezervacije();
                                Kalendar.obojiZauzeca(document.getElementById('kalendar'), mjesec-1, sala, pocetak, kraj);
                            }
                        }
                    }                    
                    req.send();
                }                
            };
        }
    }    
    function pocetnaImpl(){
        var req= new XMLHttpRequest();
        req.open('GET', 'http://localhost:8080/files');
        req.onload=function(){
            console.log('ajax');
            console.log('res', req.responseText);
            var urls=JSON.parse(req.responseText);
            console.log(urls.length, 'http://localhost:8080/slika/'+urls[1]);
            var req1=new XMLHttpRequest();
            req1.open('GET', 'http://localhost:8080/slika/'+urls[0]);
            var loadani=[];            
            req1.responseType = 'blob';
            req1.onload=function(){
                console.log('slika');
                document.getElementById('slika1').src=URL.createObjectURL(this.response);
                loadani.push(this.response);
                document.getElementById('prethodni').disabled=true;
                var req2=new XMLHttpRequest();
                req2.open('GET', 'http://localhost:8080/slika/'+urls[1]);
                req2.responseType = 'blob';
                req2.onload=function(){
                    document.getElementById('slika2').src=URL.createObjectURL(this.response);
                    loadani.push(this.response);
                    var req3=new XMLHttpRequest();
                    req3.open('GET', 'http://localhost:8080/slika/'+urls[2]);
                    req3.responseType = 'blob';
                    req3.onload=function(){
                        var br=3;
                        document.getElementById('slika3').src=URL.createObjectURL(this.response);
                        loadani.push(this.response);
                        console.log(br<urls.length);
                            document.getElementById('sljedeci').onclick=function(){
                                document.getElementById('prethodni').disabled=false;
                                var req4=new XMLHttpRequest();
                                req4.open('GET', 'http://localhost:8080/slika/'+urls[br]);
                                req4.responseType='blob';
                                req4.onload=function(){
                                    document.getElementById('slika1').src=URL.createObjectURL(this.response);
                                    loadani.push(this.response);
                                }
                                req4.send();
                                br++;
                                var req5=new XMLHttpRequest();
                                req5.open('GET', 'http://localhost:8080/slika/'+urls[br]);
                                req5.responseType='blob';
                                req5.onload=function(){
                                    document.getElementById('slika2').src=URL.createObjectURL(this.response);
                                    loadani.push(this.response);
                                }
                                req5.send();
                                br++;
                                var req6=new XMLHttpRequest();
                                req6.open('GET', 'http://localhost:8080/slika/'+urls[br]);
                                req6.responseType='blob';
                                req6.onload=function(){
                                    document.getElementById('slika3').src=URL.createObjectURL(this.response);
                                    loadani.push(this.response);
                                }
                                req6.send();
                                br++;
                                console.log('ovojebrojac', br);
                                console.log('looo', loadani);
                                if(urls.length-br<0){
                                    document.getElementById('sljedeci').disabled=true;
                                }
                                document.getElementById('prethodni').onclick=function(){
                                    console.log('hi');                                    
                                    if(document.getElementById('sljedeci').disabled==true) 
                                        document.getElementById('sljedeci').disabled=false;
                                    document.getElementById('slika1').src='http://localhost:8080/slika/'+urls[br-6];
                                    console.log(document.getElementById('slika1').src);
                                    document.getElementById('slika2').src='http://localhost:8080/slika/'+urls[br-5];
                                    document.getElementById('slika3').src='http://localhost:8080/slika/'+urls[br-4];
                                    if(br-6==0)
                                        document.getElementById('prethodni').disabled=true;
                                    br-=3;

                                }
                            }
                    } 
                    req3.send();
                }
                req2.send();

            }
            for(var i=0; i<urls.length; i+=3){
                console.log(i);
            }
            req1.send();
        }
        req.send();
        
    }
    return {
    otvoriRezervacije: otvoriRezervacijeImpl,
    rezervisi: rezervisiImpl,
    pocetna: pocetnaImpl
    }
}());
