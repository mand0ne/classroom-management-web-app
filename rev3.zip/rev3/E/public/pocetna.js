window.onload= function (){
    Pozivi.pocetna();
    //Pozivi.rezervisi();
};

