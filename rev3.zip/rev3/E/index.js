const express = require('express');
const fs = require('fs');
const app = express();
var myParser = require('body-parser');
app.use(myParser.urlencoded({extended : true}));
app.use(express.static('public'));
app.use(myParser.json());
var s;
app.get('/zauzeca', function(request, response) {
    fs.readFile('public/zauzeca.json', (err, data) => {
        if (err) throw err;
        var json = JSON.parse(data);
        s=JSON.stringify(json);        
        response.send(s);
        response.end();               
    });
});

app.post('/zauzeca.json', function(request, response) {
    var data1=request.body;
    var per_zauz=true;
    if(data1.dan==null) per_zauz=false;      
    fs.readFile('public/zauzeca.json', (err, data) => {
        if (err) throw err;
        var json = JSON.parse(data);
        if(per_zauz)
            json.periodicna.push(data1);
        else
            json.vandredna.push(data1);
        console.log(per_zauz);
        s=JSON.stringify(json);
        fs.writeFile('public/zauzeca.json', s, function(err) {
            if(err) {
                console.log(err);
            }
            else{
                console.log('success');
                response.json(s);
                response.end();
            }
        });        
    });
});
const path = require('path');
app.get('/files', function(request, response){
    var h='gheh';
    const directoryPath = path.join(__dirname, 'public/slika');
    fs.readdir(directoryPath, function (err, files) {
        if (err) {
            return console.log('Nema foldera' + err);
        } 
        console.log(directoryPath);
        var niz=[];
        files.forEach(function (file) {
            niz.push(file);
            console.log(file);
        });
        var data=JSON.stringify(niz);
        fs.writeFile('public/files.json', data, function(err) {
            if(err) {
                console.log(err);
            }
            else{
                console.log('success');
                response.send(data);
                response.end();
            }
        });
        console.log(JSON.stringify(niz));
    });    
});
app.listen(8080);