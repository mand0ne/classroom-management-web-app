pozoviModul();

function pozoviModul(){
    Pozivi.ucitajJSONPodatke();
};
