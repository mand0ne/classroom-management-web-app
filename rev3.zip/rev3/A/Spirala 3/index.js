const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");
const app = express(); 

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));
app.use(express.static(__dirname + "/public"));

app.get('/', function(req, res){
    res.sendFile(__dirname + '/public/pocetna.html');
});

app.get('/', function(req, res){  
    res.sendFile(__dirname + '/public/rezervacija.html');
});

app.get('/', function(req, res){ 
    res.sendFile(__dirname + '/public/sale.html');
});

app.get('/', function(req, res){ 
    res.sendFile(__dirname + '/public/unos.html');
});

app.get('/pozivi.js', function(req, res){
    res.sendFile(__dirname + '/public/pozivi.js');
});

app.get('/pocetna.js', function(req, res){
    res.sendFile(__dirname + '/public/pocetna.js');
});

app.get('/kalendar.js', function(req, res){
    res.sendFile(__dirname + '/public/kalendar.js');
});

app.get('/rezervacija', function(req, res){

    /*fs.readFile(__dirname + '/public/zauzeca.json', function(err, content){
        if(err) throw err;
 
        res.end(content);
    });*/
    
    var tekst = fs.readFileSync(__dirname + '/public/zauzeca.json', 'utf8');

    res.send(tekst);

});

app.post('/datum/:datum/pocetak/:pocetak/kraj/:kraj/naziv/:naziv/predavac/:predavac/checkbox/:checkbox/period/:period/kolona/:kolona', function(req, res){
    var datum1 = req.params.datum;
    var pocetak1 = req.params.pocetak;
    var kraj1 = req.params.kraj;
    var nazivSale = req.params.naziv;
    var predavac1 = req.params.predavac;
    var checkbox = req.params.checkbox; 
    var period = req.params.period;
    var kolona = req.params.kolona;

    //dodati u json file dobijene parametre
    fs.readFile(__dirname + '/public/zauzeca.json', function(err,content){
        if(err) throw err;
        
        var jsonDodaj = JSON.parse(content); 
        if(checkbox == "false") jsonDodaj["vanredna"].push({datum:datum1,
            pocetak:pocetak1,
            kraj:kraj1,
            naziv:nazivSale,
            predavac:predavac1
        });
        else jsonDodaj["periodicna"].push({dan:kolona,
            semestar:period,
            pocetak:pocetak1,
            kraj:kraj1,
            naziv:nazivSale,
            predavac:predavac1
        });
      
        fs.writeFile(__dirname + '/public/zauzeca.json', JSON.stringify(jsonDodaj), 'utf8', function(err){
            if(err) throw err;

            res.end();
        });
    });

});

app.get('/datum/:datum/pocetak/:pocetak/kraj/:kraj/naziv/:naziv/predavac/:predavac/checkbox/:checkbox/period/:period/kolona/:kolona', function(req, res){
    var datum1 = req.params.datum;
    var pocetak1 = req.params.pocetak;
    var kraj1 = req.params.kraj;
    var nazivSale = req.params.naziv;
    var predavac1 = req.params.predavac;
    var checkbox = req.params.checkbox; 
    var period = req.params.period;
    var kolona = req.params.kolona;
    var mjesec;
    var semestar;

    mjesec = parseInt(datum1.substr(3,5), 10) - 1;

    function izracunajSemestar(mjesec){
        if(mjesec == 0 || mjesec == 1 || mjesec == 10 || mjesec == 11 || mjesec == 9) return "zimski"
        if(mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5 || mjesec == 6) return "ljetni"
    }

    semestar = izracunajSemestar(mjesec);

    fs.readFile(__dirname + '/public/zauzeca.json', function(err, content){
        var obj = JSON.parse(content); 
        var pamtiStanje = false;
  
        if(checkbox == "true"){ 
            for(var i = 0; i < obj.periodicna.length; i++){
                if(obj.periodicna[i].dan == kolona && obj.periodicna[i].semestar == period && obj.periodicna[i].pocetak == pocetak1 && obj.periodicna[i].kraj == kraj1 && obj.periodicna[i].naziv == nazivSale && obj.periodicna[i].predavac == predavac1){
                    res.status(404).end("true");
                    pamtiStanje = true;
                    break;
                }
            }

            //provjera da li postoji vanredno zauzece u semestru u odgovarajucoj koloni kada zelimo da rezervisemo periodicno zauzece

            for(var i = 0; i < obj.vanredna.length; i++){
                mjesec = parseInt(obj.vanredna[i].datum.substr(3,5), 10) - 1;
                var danVanrednog = parseInt(obj.vanredna[i].datum.substr(0,2), 10);
                var kolonaPocetka = kolona;
                kolonaPocetka += danVanrednog;

                while(kolonaPocetka >= 7){
                    kolonaPocetka -= 7;
                }
                if(kolonaPocetka == 1) kolonaPocetka = 6;
                else kolonaPocetka -= 1; //zbog toga sto pocinjemo brojanje dana u sedmici od 0 do 6

                console.log(kolonaPocetka, kolona, izracunajSemestar(mjesec), period);

                if(izracunajSemestar(mjesec) == period && kolona == kolonaPocetka && obj.vanredna[i].pocetak == pocetak1 && obj.vanredna[i].kraj == kraj1 && obj.vanredna[i].naziv == nazivSale && obj.vanredna[i].predavac == predavac1) {
                    res.status(404).end("true");
                    pamtiStanje = true;
                    break;
                }
            }

            if(!pamtiStanje) res.status(200).end("false");
        } else { 
            for(var i = 0; i < obj.vanredna.length; i++){
                if(obj.vanredna[i].datum == datum1 && obj.vanredna[i].pocetak == pocetak1 && obj.vanredna[i].kraj == kraj1 && obj.vanredna[i].naziv == nazivSale && obj.vanredna[i].predavac == predavac1) {
                    res.status(404).end("true");
                    pamtiStanje = true;
                    break;
                }
            }

            //provjera da li postoji periodicno zauzece kada zelimo vanredno zauzece da rezervisemo

            for(var i = 0; i < obj.periodicna.length; i++){
                if(obj.periodicna[i].dan == kolona && obj.periodicna[i].semestar == semestar && obj.periodicna[i].pocetak == pocetak1 && obj.periodicna[i].kraj == kraj1 && obj.periodicna[i].naziv == nazivSale && obj.periodicna[i].predavac == predavac1){
                    res.status(404).end("true");
                    pamtiStanje = true;
                    break;
                }
            }

            if(!pamtiStanje) res.status(200).end("false");
        }
    });
});

app.get('/slike/:slike', function(req, res){
    var string = req.params.slike; 
    var image = parseInt(string, 10); 

    if(image != 0)
        image = 3*image; //korak kojim povecamo koju cemo sliku uzeti

    if(image + 1 <= 10) 
        res.write((1 + image) + ".png ");
    
    if(image + 2 <= 10) 
        res.write((2 + image) + ".png ");

    if(image + 3 <= 10) 
        res.write((3 + image) + ".png");

    else
        res.write("");

    res.send();
});

app.listen(8080);