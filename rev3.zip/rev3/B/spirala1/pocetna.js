function prethodni(){
    Pozivi.prethodnitest();
}
function sljedeci(){
    Pozivi.sljedecitest();
}
function prvoucitavanjepocetne(){
    Pozivi.prvoucitavanjepocetnetest();
}