function funkcija(){
    Pozivi.ucitavanje();
}
function klik(i){
    Pozivi.klikdatuma(i);
}