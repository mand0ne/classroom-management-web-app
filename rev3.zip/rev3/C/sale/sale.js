function dodajRedove (redovi = 10, kolone = 5) {
    const tabelaSala = document.getElementById("tabelaSala");

    for (let i = 1;i < redovi ;i++) {
        const tr = document.createElement("tr");
        const th = document.createElement("th");
        th.textContent = (i ) + '.';
        th.classList += "headerRedni";
        tr.appendChild(th);
        for (let j = 0; j <= kolone - 1; j++) {
            const td = document.createElement("td");
            td.classList = "sala";
            if ((j * i + 1) % 2  == 0) {
                td.classList += " slobodnaSala";
            }

            if ((j * i + 1) % 5  == 0) {
                td.classList += " zauzetaSala";
            }

            if ((j * i + 1) % 7 == 0) {
                td.classList += " kancelarija";
            }

            if (j < kolone - 1) {
                td.textContent = j + '-0' + (i );
            } else {
                td.textContent = (i % 2 === 0 ? 'VA' : 'EE') + i;
            }

            tr.appendChild(td);
        }
        tabelaSala.appendChild(tr);
    }
}