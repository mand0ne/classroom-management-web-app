const brojDanaUSedmici = 7;
const prviDanUSedmici = 1;

const opisZaglavljaDana = ["PON", "UTO", "SRI", "CET", "PET", "SUB", "NED"];

const konstante = {
    mjeseciApi: "https://api.myjson.com/bins/vfhtm",
    daniApi: "https://api.myjson.com/bins/11z9h6"
}

let trenutniDatum = new Date();
let opisMjeseca = "Novembar";
let opisGodine = "2019";

function dodajKalendar() {
    const mjesecOpis = document.getElementById("opisMjeseca");
    const godinaOpis = document.getElementById("opisGodine");
    const mjesec = dajNazivMjeseca(trenutniDatum);
    const godina = trenutniDatum.getFullYear();
    mjesecOpis.textContent = mjesec;
    godinaOpis.textContent = godina;
    dodajDaneKalendara();
}

function dodajDaneKalendara() {
    const tabelaKalendar = document.getElementById("tabelaKalendar");
    // Brisanje tabele i dodavanje zaglavlja
    tabelaKalendar.innerHTML = "";
    const zaglavlje = dajZaglavljeDana();
    tabelaKalendar.appendChild(zaglavlje);

    // Kreiranje logike za pracenje dana
    const { prvi, zadnji } = this.getPocetakIKrajMjeseca(trenutniDatum);
    let brojDana = zadnji.getDate();
    let prviDanUMjesecu = prvi.getDay();
    // getDay vraca 0 kao Nedjelju sto smatra prvim danom tako da moram za taj slucaj prilagoditi logiku
    if (prviDanUMjesecu <= 0) {
        prviDanUMjesecu = brojDanaUSedmici;
    }

    const pocetakOffset = (prviDanUMjesecu - prviDanUSedmici);
    const krajOffset = (zadnji.getDay() - brojDanaUSedmici);
    const daniOffset = pocetakOffset - krajOffset;
    brojDana += daniOffset;

    // Dodavanje dana i sedmica u kalendar
    let redSedmice = dajSedmicuUKalendaru();
    for (let i = 1;i <= brojDana;i++) { 
        let brojacDana = i - (prviDanUMjesecu - 1);

        const td = dajKolonuUKalendaru(i, brojacDana, prviDanUMjesecu, brojDana, krajOffset);
        redSedmice.appendChild(td);
    
        if (i % brojDanaUSedmici === 0) {
            if (i > 1) {
                tabelaKalendar.appendChild(redSedmice);
                redSedmice = dajSedmicuUKalendaru();
            }
        }
    }
}

function sljedeci() {
    trenutniDatum = new Date(trenutniDatum.getFullYear(), trenutniDatum.getMonth() + 1);
    dodajKalendar();
}

function prethodni() {
    trenutniDatum = new Date(trenutniDatum.getFullYear(), trenutniDatum.getMonth() - 1);
    dodajKalendar();
}

// Pomocne funkcije 

// https://stackoverflow.com/questions/13571700/get-first-and-last-date-of-current-month-with-javascript-or-jquery
function getPocetakIKrajMjeseca(datum) {
    const godina = datum.getFullYear(), mjesec = datum.getMonth();
    const prviDan = new Date(godina, mjesec, 1);
    const zadnjiDan = new Date(godina, mjesec + 1, 0);
    return {
        prvi: prviDan,
        zadnji: zadnjiDan
    }
}

function dajKolonuUKalendaru(iterator, brojacDana, prviDanUMjesecu, brojDana, krajOffset) {
    const td = document.createElement("td");

    if (iterator >= prviDanUMjesecu && iterator <= (brojDana + krajOffset)) {
        const brojDana = document.createElement("p");
        brojDana.classList += "dan";
        brojDana.textContent = brojacDana;
        td.appendChild(brojDana);
        const statusSale = document.createElement("p");
        statusSale.classList += "status";
        if ((brojacDana + 1) % 5  == 0) {
            statusSale.classList += " zauzeta";
        } else {
            statusSale.classList += " slobodna";
        }
        td.appendChild(statusSale);
        td.classList += "danKolona okvir";
    }

    return td;
}

function dajSedmicuUKalendaru() {
    const sedmica = document.createElement("tr");
    sedmica.classList += "sedmica";
    return sedmica;
}

function dajZaglavljeDana() {
    const zaglavlje = document.createElement("tr");
    zaglavlje.classList += "daniOpis";
    opisZaglavljaDana.forEach(dan => {
        zaglavlje.appendChild(dajOpisDanaKolonu(dan));
    })
    return zaglavlje;
}

function dajOpisDanaKolonu(dan) {
    const opisDana = document.createElement("th");
    opisDana.classList += "okvir";
    opisDana.textContent = dan;
    return opisDana;
}

const mapiranjeMjeseca = { 
    "January": {
        "bs": "Januar"
    }, 
    "February": {
        "bs": "Februar"
    },
    "March": {
        "bs": "Mart"
    },
    "April": {
        "bs": "April"
    },
    "May": {
        "bs": "Maj"
    },
    "June": {
        "bs": "Juni"
    },
    "July": {
        "bs": "Juli"
    },
    "August": {
        "bs": "August"
    },
    "September": {
        "bs": "Septembar"
    },
    "October": {
        "bs": "Oktobar"
    },
    "November": {
        "bs": "Novembar"
    },
    "December": {
        "bs": "Decembar"
    }
};

function dajNazivMjeseca(datum) {
    var zeljenaLokalizacija = "bs", defaultLokalizacije = "en",
        defaultnoImeMjeseca = datum.toLocaleString(defaultLokalizacije, { month: "long" }), 
        imeMjeseca = mapiranjeMjeseca[defaultnoImeMjeseca][zeljenaLokalizacija];
      return imeMjeseca;
  }

function loadJSON(path, callback) {   
    const xobj = new XMLHttpRequest();
        xobj.overrideMimeType("application/json");
    xobj.open('GET', path, true); // Replace 'my_data' with the path to your file
    xobj.onreadystatechange = function () {
          if (xobj.readyState == 4 && xobj.status == "200") {
            // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
            callback(xobj.responseText);
          }
    };
    xobj.send(null);  
}