// kod serverskih funkcionalnosti

//import { json } from '../../AppData/Local/Microsoft/TypeScript/2.6/node_modules/@types/body-parser';

var js = require("readjson");
var express = require("express");
var app = express();
var path = require("path");
var fs = require("fs");
var port = 8080;
var bodyParser = require("body-parser");
var useragent = require("express-useragent");
const expressip = require("express-ip");

var alert = require("alert-node");

app.use(express.static(path.join(__dirname + "/Zadatak1")));
app.use(express.static(path.join(__dirname + "/Zadatak2")));
app.use(express.static(path.join(__dirname + "/Zadatak3")));
app.use(express.static(path.join(__dirname + "/Zadatak4")));
app.use(expressip().getIpInfoMiddleware);
app.set("trust proxy", true);
app.use(useragent.express());

app.use(express.static("spirala"));
app.use(bodyParser.json());

app.get("/", function(req, res) {
  res.sendFile(path.join(__dirname, "/index.html"));
});

app.get("/index.css", function(req, res) {
  res.sendFile(path.join(__dirname, "/index.css"));
});

app.get("/kalendar.js", function(req, res) {
  res.sendFile(path.join(__dirname + "/kalendar.js"));
});

app.get("/Pozivi.js", function(req, res) {
  res.sendFile(path.join(__dirname + "/Pozivi.js"));
});

app.get("/Zadatak3/pocetna.html", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak3/pocetna.html"));
});

app.get("/Zadatak3/pocetna.css", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak3/pocetna.css"));
});

app.get("/Zadatak4/rezervacija.html", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak4/rezervacija.html"));
});

app.get("/Zadatak4/rezervacija.css", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak4/rezervacija.css"));
});

app.get("/Zadatak1/sale.html", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak1/sale.html"));
});

app.get("/Zadatak1/sale.css", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak1/sale.css"));
});

app.get("/Zadatak2/unos.html", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak2/unos.html"));
});

app.get("/Zadatak2/unos.css", function(req, res) {
  res.sendFile(path.join(__dirname, "/Zadatak2/unos.css"));
});

app.get("/zauzeca", function(req, res) {
  let jsonData = fs.readFileSync("zauzeca.json");
  let sale = JSON.parse(jsonData);

  res.json(sale);
});

app.get("/slike", function(req, res) {
  let jsonData = fs.readFileSync("slike.json");
  let slike = JSON.parse(jsonData);
  res.json(slike);
});

app.get("/Zadatak3/pocetna", function(req, res) {
  let jsonData = fs.readFileSync("posjetioci.json");
  let browser = JSON.parse(jsonData);
  if (req.useragent.isChrome) browser.pretrazivaci[0].chrome += 1;
  if (req.useragent.isFirefox) browser.pretrazivaci[0].mozilla += 1;
  if (req.useragent.isOpera) browser.pretrazivaci[0].opera += 1;
  if (req.useragent.isSafari) browser.pretrazivaci[0].safari += 1;

  fs.writeFile("./posjetioci.json", JSON.stringify(browser), function(error) {
    if (!error) res.json(browser);
  });
});

app.get("/ipadresa", function(req, res) {
  let jsonData = fs.readFileSync("ipadrese.json");
  let ipadresa = JSON.parse(jsonData);
  let postoji = true;
  var ip = (
    req.headers["x-forwarded-for"] ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress
  ).split(",")[0];
  for (i = 0; i < ipadresa.ipadrese.length; i++) {
    if (ipadresa.ipadrese[i].ip === ip) postoji = false;
  }
  if (postoji) {
    ipadresa.ipadrese.push({
      ip: ip
    });
  }

  fs.writeFile("./ipadrese.json", JSON.stringify(ipadresa), function(error) {
    if (!error) res.json(ipadresa);
  });
});

app.get('/PocetnaTEMP.js',function(req,res){
  res.sendFile(path.join(__dirname + '/PocetnaTEMP.js')); 
});

app.post('/ucitajSlike',function(req, res) {
  let jsonData = fs.readFileSync('slike.json');
  let data = JSON.parse(jsonData);
  const stranica = parseInt(req.body.stranica, 10);
  const noveSlike = data.slike.slice(stranica*3, stranica*3+3)
  res.json({slike: noveSlike, ostalo: data.slike.length - (stranica+1)*3});
});

app.post("/zauzeca", function(req, res) {
  let jsonData = fs.readFileSync("zauzeca.json");
  let sale = JSON.parse(jsonData);
  const zimski = [0, 9, 10, 11];
  const zauzece = req.body;
  if (req.body.periodicna) {
    const datumcic = new Date(
      req.body.datum.substr(3, 2) + "." + req.body.datum.substr(0, 2) + ".2019"
    );
    const dan = datumcic.getDay() ? datumcic.getDay() - 1 : 6;
    const mjesec = datumcic.getMonth();

    var slobodnaPeriodicnaSala = true;
    var slobodnaVanrednaSala = true;

    for (i = 0; i < sale.periodicna.length; i++) {
      if (
        zauzece.naziv === sale.periodicna[i].naziv &&
        zauzece.pocetak >= sale.periodicna[i].pocetak &&
        zauzece.kraj <= sale.periodicna[i].kraj
      ) {
        alert(
          `Nije moguće rezervisati salu ${zauzece.naziv} za navedeni datum ${zauzece.datum} i termin od ${zauzece.pocetak} do ${zauzece.kraj}!`
        );
        slobodnaPeriodicnaSala = false;
        break;
      }
    }
    if (slobodnaPeriodicnaSala) {
      sale.periodicna.push({
        dan: dan,
        semestar: zimski.includes(mjesec) ? "zimski" : "ljetni",
        pocetak: zauzece.pocetak,
        kraj: zauzece.kraj,
        naziv: zauzece.naziv,
        predavac: "Himzo"
      });
    }
  } else {
    for (i = 0; i < sale.vanredna.length; i++) {
      if (
        zauzece.naziv === sale.vanredna[i].naziv &&
        zauzece.pocetak >= sale.vanredna[i].pocetak &&
        zauzece.kraj <= sale.vanredna[i].kraj &&
        zauzece.datum === sale.vanredna[i].datum
      ) {
        alert(
          `Nije moguće rezervisati salu ${zauzece.naziv} za navedeni datum ${zauzece.datum} i termin od ${zauzece.pocetak} do ${zauzece.kraj}!`
        );
        slobodnaVanrednaSala = false;
        break;
      }
    }
    if (slobodnaVanrednaSala) {
      sale.vanredna.push({
        datum: zauzece.datum,
        pocetak: zauzece.pocetak,
        kraj: zauzece.kraj,
        naziv: zauzece.naziv,
        predavac: "Himzo"
      });
    }
  }
  fs.writeFile("./zauzeca.json", JSON.stringify(sale), function(error) {
    if (!error) res.json(sale);
  });
});

app.listen(port);

console.log("Now listening on port " + port);
