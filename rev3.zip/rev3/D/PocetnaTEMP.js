let slike = [];
let zadnjeSlike = []
let trenutnaStranica = 0;
let zadnjaStranica = 0;
let ostaloSljedecih = 10000;
let ostaloPrethodnih = -10000;

var pretrazivaci = null;
ucitajPretrazivace();

var ipadrese = null;
ucitajIpAdrese();

ucitajSljedeceSlike(0);

function prethodna(){
    const button = document.getElementById('prethodna')
    button.disabled = false
    const buttonSljedeci = document.getElementById('sljedeca')
    buttonSljedeci.disabled = false
    trenutnaStranica--;
    zadnjeSlike = slike.slice((trenutnaStranica-1)*3, (trenutnaStranica-1)*3+3);

    ostaloPrethodnih = trenutnaStranica*3 - 3;
    prikaziSlike();
    if(ostaloPrethodnih < 1) {
        button.disabled = true
    }

}

function sljedeca(){
    const button = document.getElementById('prethodna')
    button.disabled = false
    zadnjeSlike=[];
    ucitajSljedeceSlike(trenutnaStranica);
    if(ostaloSljedecih < 1) {
        const buttonSljedeci = document.getElementById('sljedeca')
        buttonSljedeci.disabled = false
    }
}

function prikaziSlike(){
    const container = document.getElementById("grid-container");
    container.innerHTML = "";
    zadnjeSlike.forEach(element => {
        // treba napraviti
        // <div class="grid-item">
        //     <img class="grid-image" src="https://img.freepik.com/free-vector/abstract-dynamic-pattern-wallpaper-vector_53876-59131.jpg?size=338&ext=jpg"></img>
        // </div>
        
        const divGlavni = document.createElement("div");
        divGlavni.className = "grid-item";
        const slika = document.createElement("img");
        slika.className="grid-image";
        slika.src=element;

        divGlavni.append(slika);
        container.append(divGlavni);
    });
}