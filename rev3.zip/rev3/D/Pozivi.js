function pocetna() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200)
      document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/Zadatak3/pocetna.html", true);
  ajax.send();
}
function unos() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200)
      document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/Zadatak2/unos.html", true);
  ajax.send();
}
function rezervacija() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200)
      document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/Zadatak4/rezervacija.html", true);
  ajax.send();
}
function sale() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200)
      document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/Zadatak1/sale.html", true);
  ajax.send();
}

function ucitaj() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200) {
      Kalendar.ucitajPodatke(
        JSON.parse(ajax.response).periodicna,
        JSON.parse(ajax.response).vanredna
      );
      Kalendar.iscrtajKalendar(
        document.getElementById("kalendar"),
        new Date(Date.now()).getMonth()
      );
      return JSON.parse(ajax.response);
    }
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/zauzeca", true);
  ajax.send();
}

function ucitajSlike(stranica) {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200) {
      return ajax.response;
    }
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("sadrzaj").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/slike", true);
  ajax.send();
}

function ucitajPretrazivace() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200) {
      pretrazivaci = JSON.parse(ajax.response).pretrazivaci[0];
      document.getElementById("chrome").innerHTML =
        "Broj Chrome korisnika: " + pretrazivaci.chrome;
      document.getElementById("firefox").innerHTML =
        "Broj Firefox korisnika: " + pretrazivaci.mozilla;
      document.getElementById("opera").innerHTML =
        "Broj Opera korisnika: " + pretrazivaci.safari;
      document.getElementById("safari").innerHTML =
        "Broj Safari korisnika: " + pretrazivaci.opera;

      return pretrazivaci;
    }
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("sadrzaj").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/Zadatak3/pocetna", true);
  ajax.send();
}

function ucitajIpAdrese() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200) {
      ipadrese = JSON.parse(ajax.response).ipadrese;
      document.getElementById("ip").innerHTML =
        "Broj razlicith ip adresa: " + ipadrese.length;

      return ipadrese.length;
    }
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("sadrzaj").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("GET", "http://localhost:8080/ipadresa", true);
  ajax.send();
}

function unesiZauzece(zauzece) {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200) {
      Kalendar.ucitajPodatke(
        JSON.parse(ajax.response).periodicna,
        JSON.parse(ajax.response).vanredna
      );
      Kalendar.iscrtajKalendar(
        document.getElementById("kalendar"),
        new Date(Date.now()).getMonth()
      );
    }
    if (ajax.readyState == 4 && ajax.status == 404) alert("NONOOOO");
  };
  ajax.open("POST", "http://localhost:8080/zauzeca", true);
  ajax.setRequestHeader("Content-Type", "application/json");
  ajax.send(JSON.stringify(zauzece));
}

function ucitajSljedeceSlike(sljedecaStranica) {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200) {
      const noveSlike = JSON.parse(ajax.response).slike;
      noveSlike.forEach(element => {
        slike.push(element);
        zadnjeSlike.push(element);
      });
      trenutnaStranica++;
      zadnjaStranica++;
      ostaloSljedecih = JSON.parse(ajax.response).ostalo;
      ostaloPrethodnih = trenutnaStranica * 3 - 3;

      if (ostaloPrethodnih < 1) {
        const button = document.getElementById("prethodna");
        button.disabled = true;
      }
      if (ostaloSljedecih < 1) {
        const buttonSljedeci = document.getElementById("sljedeca");
        buttonSljedeci.disabled = true;
      }
      prikaziSlike();
      return ajax.response;
    }
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
  };
  ajax.open("POST", "http://localhost:8080/ucitajSlike", true);
  ajax.setRequestHeader("Content-Type", "application/json");
  ajax.send(JSON.stringify({ stranica: sljedecaStranica }));
}
