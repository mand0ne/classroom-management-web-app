
Pozivi.ucitajSlike();

function prethodneAkcija() {
    Pozivi.ucitajSlike("prethodne");
}

function sljedeceAkcija() {
    Pozivi.ucitajSlike("sljedece");
}